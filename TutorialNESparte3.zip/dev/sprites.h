const unsigned char sprPlayerLeft[]={//datos del sprite del personaje
//  x,  y,elemento, serie de colores
	8,	0,	0x44,	0|0x40,//En este caso es el personaje principal volteado a la izquierda
	0,	0,	0x45,	0|0x40,
	8,	8,	0x54,	0|0x40,
	0,	8,	0x55,	0|0x40,
	128
};

const unsigned char sprPlayerRight[]={//Personaje principal volteado a la derecha
	0,	0,	0x44,	0,
	8,	0,	0x45,	0,
	0,	8,	0x54,	0,
	8,	8,	0x55,	0,
	128
};

const unsigned char sprPlayerWalkLeft[]={//Personaje caminando a la izquierda
	8,	8,	0x56,	0|0x40,
	0,	8,	0x57,	0|0x40,
	128
};

const unsigned char sprPlayerWalkRight[]={//Personaje caminando a la derecha
	0,	8,	0x56,	0,
	8,	8,	0x57,	0,
	128
};

const unsigned char sprEnemy01Left[]={//Emenigo #1 volteado a la izquierda
	8,	0,	0x64,	1|0x40,
	0,	0,	0x65,	1|0x40,
	8,	8,	0x74,	1|0x40,
	0,	8,	0x75,	1|0x40,
	128
};

const unsigned char sprEnemy01Right[]={//Emenigo #1 volteado a la derecha
	0,	0,	0x64,	1,
	8,	0,	0x65,	1,
	0,	8,	0x74,	1,
	8,	8,	0x75,	1,
	128
};

const unsigned char sprEnemy01WalkLeft[]={//Emenigo #1 caminando a la izquierda
	8,	8,	0x76,	1|0x40,
	0,	8,	0x77,	1|0x40,
	128
};

const unsigned char sprEnemy01WalkRight[]={//Emenigo #1 caminando a la derecha
	0,	8,	0x76,	1,
	8,	8,	0x77,	1,
	128
};

const unsigned char sprEnemy02[]={//Enemigo #2
	0,	0,	0x48,	2,
	8,	0,	0x48,	2|0x40,
	0,	8,	0x58,	2,
	8,	8,	0x58,	2|0x40,
	128
};

const unsigned char sprEnemy03a[]={//Enemigo #3 girando (1ra animacion)
	0,	0,	0x49,	3,
	8,	0,	0x4a,	3,
	0,	8,	0x59,	3,
	8,	8,	0x59,	3|0x40,
	128
};

const unsigned char sprEnemy03b[]={//Enemigo #3 girando (2da animacion)
	0,	0,	0x5a,	3,
	8,	0,	0x5a,	3|0x40,
	0,	8,	0x59,	3,
	8,	8,	0x59,	3|0x40,
	128
};

const unsigned char sprEnemy03c[]={//Enemigo #3 girando (3ra animacion)
	8,	0,	0x49,	3|0x40,
	0,	0,	0x4a,	3|0x40,
	8,	8,	0x59,	3|0x40,
	0,	8,	0x59,	3,
	128
};

const unsigned char sprEnemy03d[]={//Enemigo #3 girando (4ta animacion)
	8,	0,	0x59,	3|0xc0,
	0,	0,	0x59,	3|0x80,
	8,	8,	0x59,	3|0x40,
	0,	8,	0x59,	3,
	128
};


const unsigned char* const num_spr_jugador[]={//Creamos una lista de los sprites del personaje para localizar facilmente cada uno
	sprPlayerLeft, sprPlayerWalkLeft,
	sprPlayerRight, sprPlayerWalkRight,
};

const unsigned char* const num_spr_enemigos[]={//Creamos una lista de los sprites de los enemigos para localizar facilmente cada uno
	sprEnemy01Left,sprEnemy01WalkLeft,
	sprEnemy01Right,sprEnemy01WalkRight,
	sprEnemy02,sprEnemy03a,
	sprEnemy03b,sprEnemy03c,sprEnemy03d,
};