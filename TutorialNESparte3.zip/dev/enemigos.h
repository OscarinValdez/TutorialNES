#include "build/nivel_1_enems.h"
#include "build/nivel_2_enems.h"

const unsigned int *const lista_niveles_enems[]={//creamos un grupo de todas las listas de enemigos por nivel por si desean agregar mas a su proyecto
	nivel_1_enems,nivel_2_enems,
};

void cargar_enemigos(void)//cargamos los datos de los enemigos (x, y, tipo, salud, vel y, direccion, en pantalla, (des)activado)
{
	for (i=0;i<((sizeof(lista_niveles_enems[idx]))<<2);++i)
	{
		enem_x[i]=		(lista_niveles_enems[idx])[i<<2];
		enem_y[i]=		(lista_niveles_enems[idx])[(i<<2)+1];
		enem_tipo[i]=	(lista_niveles_enems[idx])[(i<<2)+2];
		enem_hp[i]=		(lista_niveles_enems[idx])[(i<<2)+3];
		
		enem_vy[i]= 	0;
		enem_dir[i]=	0;
		en_pantalla[i]= 0;
		enem_desact[i]= 0;
	}
}
//Funciones que definen el comportamiento de cada uno de los enemigos
void mover_enemigo01(void)
{	//fijar cuadriculas como en el personaje
	i16=enem_x[i]>>4;
	j16=(enem_y[i]>>4);
	cix=(enem_x[i]-3)>>4;
	k32=(enem_x[i]+15)>>4;
	
	if (enem_dir[i]) ++enem_x[i]; else --enem_x[i];//dependiento en la direccion es donde se va a mover
	
	if (nivel_cuadricula[(j16<<4)+(cix&15)]==6) enem_dir[i]=1;//si toca algun objeto solido que cambie de direccion
	if (nivel_cuadricula[(j16<<4)+((i16+1)&15)]==6)  enem_dir[i]=0;
	
	if ((nivel_cuadricula[((j16+1)<<4)+(i16&15)]==6)//colisionar con el piso
	&& (nivel_cuadricula[((j16+1)<<4)+(k32&15)]==6))
		enem_y[i]=j16<<4;
	else
		enem_y[i]+=5;//o caerse
}

void mover_enemigo02(void)
{
	if (enem_vy[i]>4) enem_vy[i]=4;
	else ++enem_vy[i];
	
	enem_y[i]+=enem_vy[i];
	
	i16= (enem_x[i] >> 4);
	k32= ((enem_x[i]+12) >> 4);
	j16= ((enem_y[i] >> 4)+1);

	if ((nivel_cuadricula[(j16<<4)+(i16&15)]==6)
	&& (nivel_cuadricula[(j16<<4)+(k32&15)]==6) && enem_vy[i]>=0)
	enem_vy[i]-=18;//Solo rebota
}

void mover_enemigo03(void)
{
	i16= (enem_x[i] >> 4);
	k32= ((enem_x[i]+12) >> 4);
	j16= (enem_y[i] >> 4);
	cix= ((enem_y[i]+12) >> 4);
	
	//Solo vuela hacia al jugador
	if (pl_x<enem_x[i] && (nivel_cuadricula[(j16<<4)+((i16-1)&15)]!=6)&& (nivel_cuadricula[(cix<<4)+((i16-1)&15)]!=6)) --enem_x[i];
	else if (pl_x>=enem_x[i] && (nivel_cuadricula[(j16<<4)+((i16+1)&15)]!=6) && (nivel_cuadricula[(cix<<4)+((i16-1)&15)]!=6)) ++enem_x[i];
	
	if (pl_y<enem_y[i] && (nivel_cuadricula[((j16-1)<<4)+(i16&15)]!=6) && (nivel_cuadricula[((j16-1)<<4)+(k32&15)]!=6)) --enem_y[i]; 
	else if (pl_y>=enem_y[i] && (nivel_cuadricula[((j16+1)<<4)+(i16&15)]!=6) && (nivel_cuadricula[((j16-1)<<4)+(k32&15)]!=6)) ++enem_y[i];
}