// Simple UNROM template

// Uses neslib by Shiru.
// Includes tokumaru's lzss decompressor.
// Bankswitching code adapted from nesdev wiki's

// Put together by na_th_an. Find me around nesdev.com if you need help.

#include "neslib-unrom.h"
#include "definitions.h"

#pragma bssseg (push,"ZEROPAGE")
#pragma dataseg(push,"ZEROPAGE")

#include "ram/zp.h"

#pragma bssseg (push,"BSS")
#pragma dataseg(push,"BSS")

#include "ram/bss.h"

#pragma rodataseg	("ROM0")
#pragma codeseg	("ROM0")

#include "rom/rom0.h"
extern const unsigned char MiMusica[];

#pragma rodataseg	("ROM1")
#pragma codeseg	("ROM1")

#include "rom/rom1.h"
#include "sprites.h"
#include "colores.h"
#include "fondo.h"
#include "niveles.h"
#include "cargar.h"
#include "enemigos.h"
#include "visualizar.h"
#include "jugador.h"

#pragma rodataseg	("ROM2")
#pragma codeseg	("ROM2")

#include "rom/rom2.h"
#include "graficos.h"

#pragma rodataseg	("CODE")
#pragma codeseg	("CODE")

#include "desplazamiento.h"

// main code (@ fixed bank) goes here:
void main(void)
{	
	bank_bg (0);
	bank_spr (0);
	
	famitone_init(0,MiMusica);
	
	bankswitch(2);
	ppu_off();
	descomprimir_graficos();
	ppu_on_all();

	bankswitch(1);

	cargar_nivel();//Precargamos los datos mencionados
	visualizar_el_nivel();//vease los archivos cargar.h y visualizar.h
	
	cargar_lista();
	cargar_enemigos();
	 
	i16=1;//Precargamos la columna a actualizarse durante el desplazamiento de la pantalla
	ii= ((pl_x+8)>>4)+8;//Mera derecha
	trazar_columna();
	
	pal_spr(palSprites);//Carga los colores de los sprites
	pal_bg(palWorldField);//Carga los colores del fondo

	music_play(0);//Empieza a reproducir la musica
	
	while(1)//Ciclo bucle que se ejecutará durante el juego
	{
		spr=0;//Cargar los sprites del personaje para cada fotograma que se ejecute
				//show_x es el eje x dentro de la pantalla y que se va a controlar durante el desplazamiento
		spr=oam_meta_spr(show_x,pl_y,spr,num_spr_jugador[sprite_idx+((fotograma>>2)&1)]);

		//
		if (pl_x>120) camara_x= pl_x-120; else camara_x =0;//si el personaje ya va por la mitad de la pantalla entonces recorrer la pantalla
		///
		mover_jugador();//funcion para controlar al personaje (vease el archivo jugador.h)
		
		//si el personaje ya va por la mitad de la pantalla y no se pasa del limite del nivel entonces que empieze el desplazamiento de la misma
		if (pl_x > 120 && pl_x < (max_pantalla[idx]<<8)-136)
		{
			if (((old_camara_x>>3)<<3) < ((camara_x>>3)<<3)) //si la camara se recorrio a la derecha
			{	
				ii= ((pl_x+8)>>4)+8;//vriable que se usara como puntero para indicar la orilla de la derecha y cargar los nuevos elemento ahi
				k32= ((camara_x>>8)%2==0?0x27:0x23);//depende en cual nametable nos ubicamos
				i16=1;//Aqui se usarra para saber a que direccion actualizar (0=izquierda, 1=derecha)
				trazar_columna();//Actualizamos la columna correspondiente (ver el archivo desplazamiento.h)
			}
			else if (((old_camara_x>>3)<<3) > ((camara_x>>3)<<3))//Caso de la izquierda
			{
				ii= (pl_x>>4)-7;//very left of screen
				k32= ((camara_x>>8)%2==0?0x23:0x27);
				i16=0;
				trazar_columna();
			}
			
			scroll(camara_x,0);//desplazamos la pura pantalla a los ejes indicados (x,y)
			scr_x = pl_x-120;
			show_x = 120; //para colocar fijamente al personaje en medio de la pantalla
		}
		else
		{
			if (pl_x<=120) { jj=0; kk=0; scroll(0,0); }//Si el personaje se regreso al principio del nivel entonces que recinicie los punteros
			show_x = pl_x;//que sea igual al eje x ya que ya no hay desplazamiento
			//fijar la pantalla al principio
		}
		
		if ( scr_x > enem_x[rango] ) ++rango;//calcular el rango MAX 4 enemigos por pantalla
		else if (rango && scr_x < enem_x[rango-1] && !en_pantalla[rango]) --rango;
		
		visualizar_enemigos();
		++enem_anim;
		visualizar_municiones();
		visualizar_datos();
		
		oam_hide_rest(spr);//le decimos que ya termino de visualizar los sprites

		update_list[60]=NT_UPD_EOF;//termino con la lista de tiles a actualizarse
		set_vram_update(update_list);//actualizamos ya la lista

		ppu_wait_nmi();//siguiente fotograma. controla la velocidad del juego. sin esto habra conflictos durante la visualizacion
	}
	
}