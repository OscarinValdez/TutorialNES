void extender_arriba(void)
{//Este procedimiento es para extender los bloques cuyo id es 62
	tira=j+2;//preparando para crear una columna (o tira de bloques) hacia arriba
	tira-=2;
	while (tira>2)
	{
		update_list[tira-1]=0x88+((camara_x>>3)&1);//tile de los bloques (0x88 y 0x98 segun en el yy-chr +)
		update_list[tira]=0x98+((camara_x>>3)&1);
		nivel_cuadricula[(((lista_niveles[(idx<<1)])[jj])>>4)+((((tira>>1)&15))<<4)]=6;//actualizarlo en la cuadricula a estado solido (cuadro correspondiente)
		tira-=2;//y asi sucesivamente hacia arriba
	}
	tira=(j>>2)-1;
}

void extender_abajo(void)
{//Este procedimiento es para extender los bloques cuyo id es 63
	tira=j;//preparando para crear una columna (o tira de bloques) hacia abajo
	while (tira<30)
	{
		update_list[tira-1]=0x88+((camara_x>>3)&1);//tile de los bloques (0x88 y 0x98 segun en el yy-chr +)
		update_list[tira]=0x98+((camara_x>>3)&1);
		nivel_cuadricula[(((lista_niveles[(idx<<1)])[jj])>>4)+((((tira>>1)&15))<<4)]=6;//actualizarlo en la cuadricula a estado solido (cuadro correspondiente)
		tira+=2;//y asi sucesivamente hacia abajo
	}
	tira=(j>>2)-1;
}

void __fastcall__ trazar_columna(void) //dibujar una parte del nivel (en columna) justo despues de la orilla de la pantalla (izquierda o derecha)
{//Para mas informacion de esto ver mi cuarto Oscarindie vlog en mi cuenta de Youtube (Oscarin Valdez) que trata del desplazamiento (scrolling)
	
	for (i=0;i<15;++i)
	{
		nivel_cuadricula[(ii&15)+(i<<4)]=0;//Vaciar una columna de cuadriculas para colocar nuevos objetos y quitar ya los innecesarios
	}
		
	if (i16==1)//Localiza que es lo que sigue hacia la derecha de la pantalla para poder colocar los nuevos objetos de acuerdo a los datos del nivel correspondiente
	{
		while ((((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj+1])>>3)<<4)<ii )//Bloques para el fondo
		jj+=2;
	
		while ((((lista_niveles[(idx<<1)+1])[kk])>>4)+((((lista_niveles[(idx<<1)+1])[kk+1])>>3)<<4)<ii )//Objetos (monedas)
		kk+=3;
	
		update_list[0]=((camara_x>>8)%2==0?0x24:0x20)|NT_UPD_VERT;//Localiza la posicion XY correspondientes de la pantala (derecha de la orilla) para actualizarlos en forma vertical
		update_list[1]=0x80+((camara_x>>3)&31);//0x2080 para nametable A o 0x2480 para nametable B
	}
	else if (i16==0)//Localiza que es lo que sigue hacia la izquierda de la pantalla para poder colocar los nuevos objetos de acuerdo a los datos del nivel correspondiente
	{
		while ((((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj+1])>>3)<<4)>ii && jj>=2)//Bloques para el fondo
		jj-=2;
	
		while ((((lista_niveles[(idx<<1)+1])[kk])>>4)+((((lista_niveles[(idx<<1)+1])[kk+1])>>3)<<4)>ii && kk>=3)//Objetos (monedas)	
		kk-=3;
	
		update_list[0]=((camara_x>>8)%2==0?0x20:0x24)|NT_UPD_VERT;//Localiza la posicion XY correspondientes de la pantala (izquierda de la orilla) para actualizarlos en forma vertical
		update_list[1]=0x80+(((camara_x>>3)+1)&31);//0x2080 para nametable A o 0x2480 para nametable B
	}
	
	update_list[2]=26;//26 es es total de tiles en forma vertical (columna de tiles)
	
	for (i=0;i<26;++i)
	{	
		update_list[i+3]=0;//Los vaciamos para poner nuevos tiles y quitar los que ya no necesitemos
	}
	
	// Aqui la variable cix se usará para localizar las posiciones XY de los datos de los bloques del nivel correspondiente
	cix = (((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj+1])>>3)<<4);
	
	if (((pl_x>>4)+1)%2==!i16)//Actualizamos primero la paleta de colores (en columna)
	{//Esto es cada dos veces que se actualiza la pantalla ya que los atributos (colores) ocupan cuadriculas de 2x2
		update_list[29]=k32;//Desde arriba hacia abajo
		update_list[30]=0xc8+((camara_x>>5)&7);
		update_list[31]=0;
		
		update_list[32]=k32;
		update_list[33]=0xc8+((camara_x>>5)&7)+8;
		update_list[34]=0;
		
		update_list[35]=k32;
		update_list[36]=0xc8+((camara_x>>5)&7)+16;
		update_list[37]=0;
		
		update_list[38]=k32;
		update_list[39]=0xc8+((camara_x>>5)&7)+24;
		update_list[40]=0;

		update_list[41]=k32;
		update_list[42]=0xc8+((camara_x>>5)&7)+32;
		update_list[43]=0;

		update_list[44]=k32;
		update_list[45]=0xc8+((camara_x>>5)&7)+40;
		update_list[46]=0;
		
		update_list[47]=k32;
		update_list[48]=0xc8+((camara_x>>5)&7)+48;
		update_list[49]=0;
	}
	
	k32=jj;//Respaldamos para repetir con la segunda mitad de la columna de cuadriculas
	//(cada columna de cuadriculas son dos columnas de tiles)

	///Dibujar los bloques en el piso (dos ultimas hileras de abajo)
	
	update_list[25]= (metatile_idx[7])[(!i16+(camara_x>>3))&1];
	update_list[26]= (metatile_idx[7])[2+(((camara_x>>3)-!i16)&1)];
	update_list[27]= (metatile_idx[7])[(!i16+(camara_x>>3))&1];
	update_list[28]= (metatile_idx[7])[2+(((camara_x>>3)-!i16)&1)];
	nivel_cuadricula[(ii&15)+(13<<4)]=6;//Actualizar la cuadricula a estado solido
	
	
	while(cix==ii)//Mientras que el puntero ii esté en la misma columna de cuadriculas que haga lo siguente:
	{
					j=(((lista_niveles[(idx<<1)])[jj])&15)<<1;//prepara la lista de la columna de tiles (mitad cuadricula) a actualizarse en pantalla
					if (i16==1)//A la orilla Derecha
					{	//Prepararse para dibujar los bloques (mitad arriba y mitad abajo)
						update_list[j-1]= (metatile_idx[(((lista_niveles[(idx<<1)])[jj+1])&7)])[(camara_x>>3)&1];//(level1[idl])[ii+2]
						update_list[j]= (metatile_idx[(((lista_niveles[(idx<<1)])[jj+1])&7)])[2+((camara_x>>3)&1)];
					}
					else if (i16==0)//A la orilla Izquierda
					{
						update_list[j-1]= (metatile_idx[(((lista_niveles[(idx<<1)])[jj+1])&7)])[!((camara_x>>3)&1)];//(level1[idl])[ii+2]
						update_list[j]= (metatile_idx[(((lista_niveles[(idx<<1)])[jj+1])&7)])[2+!((camara_x>>3)&1)];
					}
					
					
						if ((((lista_niveles[(idx<<1)])[jj+1])&7)>0)//Actualizarlos ahora en la cuadricula
						{						//Posicion XY en la cuadricula
							nivel_cuadricula[(((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj])&15)<<4)]=6;
							
							switch (((lista_niveles[(idx<<1)])[jj+1])&7)
							{
								case 4: extender_arriba(); break;//Si hay un bloque extendible que llame a la funcion mencionada a mero arriba de este archivo
								case 5: extender_abajo(); break;//Si hay un bloque extendible que llame a la funcion mencionada arriba de este archivo
							}
						}
						else if ((((lista_niveles[(idx<<1)])[jj+1])&7)==0)//Si hay un hoyo vacio entre bloques poner no solido y borrar parte del fondo
						{
							nivel_cuadricula[(((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj])&15)<<4)]=0;
							update_list[25]= 0;//Dos ultimas cuadriculas de abajo
							update_list[26]= 0;
							update_list[27]= 0;
							update_list[28]= 0;
						}
						
						j=(((lista_niveles[(idx<<1)])[jj])&15)>>1;//Ahora a preparar para colorear (atributos)
						
						if ((((lista_niveles[(idx<<1)])[jj+1])&7)==6) //Si es una cuadricula solida que sea en grises
						update_list[j+j+j+28]=0;//Del update_list[29] al [49] que se usarán para los colores

		if (i16==1)	jj+=2;//Movemos en puntero ya sea izquierda o derecha segun sea el caso para actualizar lo que sigue en la misma columna
		else if(i16==0) jj-=2;
						
		cix = (((lista_niveles[(idx<<1)])[jj])>>4)+((((lista_niveles[(idx<<1)])[jj+1])>>3)<<4);
	}
	jj=k32;	//Respaldamos para la segunda mitad de la columna de tiles (cada columna de cuadriculas son dos columnas de tiles)
	
	
	cix=kk; //Respaldamos ahora los objetos (monedas)
	
	/// OBJETOS :
	// Aqui la variable cix se usará para localizar las posiciones XY de los datos de las monedas del nivel correspondiente
	while(((((lista_niveles[(idx<<1)+1])[kk])>>4)+((((lista_niveles[(idx<<1)+1])[kk+1])>>3)<<4))==ii)
	{
		j=(((lista_niveles[(idx<<1)+1])[kk])&15)<<1;//prepara la lista de la columna de tiles (mitad cuadricula) a actualizarse en pantalla
		j16=0;//Limpiamos los atributos para nuevos colores
		if (!got[((lista_niveles[(idx<<1)+1])[kk+2])])//Si la moneda aun no es coleccionada que lo prepare para dibujar
		{
			if (i16==1)//A la orilla Derecha
			{
				update_list[j-1]= (metatile_idx[(((lista_niveles[(idx<<1)+1])[kk+1])&7)])[(camara_x>>3)&1];
				update_list[j]= (metatile_idx[(((lista_niveles[(idx<<1)+1])[kk+1])&7)])[2+((camara_x>>3)&1)];
			}
			else if (i16==0)//A la orilla Izquierda
			{
				update_list[j-1]= (metatile_idx[(((lista_niveles[(idx<<1)+1])[kk+1])&7)])[!((camara_x>>3)&1)];
				update_list[j]= (metatile_idx[(((lista_niveles[(idx<<1)+1])[kk+1])&7)])[2+!((camara_x>>3)&1)];
			}
			
			if ((((lista_niveles[(idx<<1)+1])[kk+1])&7)>0)//Actualizamos la cuadricula poniendo el id correspondiente de la moneda
			{
				nivel_cuadricula[(((lista_niveles[(idx<<1)+1])[kk])>>4)+((((lista_niveles[(idx<<1)+1])[kk])&15)<<4)]=(lista_niveles[(idx<<1)+1])[kk+2];//4;//((lista_niveles[(idx<<1)])[0])+1+3;//(level1[idl])[(jj+1)]==13?0:(level1[idl])[(jj+2)];
				j16=((3 << 0) + (3 << 2) + (3 << 4) + (3 << 6));//Preparamos para colorear en Amarillo
				//Como lo mencione arriba, los atributos (colores) ocupan cuadriculas de 2x2
				//Valor = (arriba_izq << 0) + (arriba_der << 2) + (abajo_izq << 4) + (abajo_der << 6)
				//En este caso el valor 3 es el grupo de colores para el amarillo
			}
		}
		
		switch ((lista_niveles[(idx<<1)+1])[kk+2])//Si se trata de otros objetos como la puerta
		{
			case 1://Dibujar flores
				update_list[j-1]=0;
				update_list[j]=0x79;
			break;
			case 2://Dibujar la puerta y ponerlo en la cuadricula correspondiente
				update_list[j-1]=0x8a+(i16?((camara_x>>3)&1):!((camara_x>>3)&1));
				update_list[j]=0x9a+(i16?((camara_x>>3)&1):!((camara_x>>3)&1));
				nivel_cuadricula[(((lista_niveles[(idx<<1)+1])[kk])>>4)+((((lista_niveles[(idx<<1)+1])[kk])&15)<<4)]=2;
			break;
		}
		
		//PALETA DE COLORES		value = (bottomright << 6) | (bottomleft << 4) | (topright << 2) | (topleft << 0)
		j=(((lista_niveles[(idx<<1)+1])[kk])&15)>>1;//	(arriba_izq << 0) + (arriba_der << 2) + (abajo_izq << 4) + (abajo_der << 6)
		//Ahora a preparar para colorear (atributos)
		
		update_list[j+j+j+28]=(j16);//Del update_list[29] al [49] que se usarán para los colores
			
		if (i16==1)	kk+=3;//Movemos en puntero ya sea izquierda o derecha segun sea el caso para actualizar lo que sigue en la misma columna
		else if(i16==0) kk-=3;
	}
	kk=cix;//Respaldamos para la segunda mitad de la columna de tiles (cada columna de cuadriculas son dos columnas de tiles)

	old_camara_x = camara_x;//Actualizamos para que no llame a esta funcion todo el tiempo
}