void visualizar_el_nivel(void)
{	
	for (i=0;i<240;++i)//Empieza a calcular todo el mapa para dibujar los bloques
	{
		if (nivel_cuadricula[i]==6)//si en el cuadro indicado esta un bloque entonces que lo dibuje
		{			// 0x2000 es el inicio de la pantalla. (i<<1)
			vram_adr(0x2000+(i<<1)+((i>>4)<<5)); 	  vram_put(metblock[0]);//Va de 4x4 tiles
			vram_adr(0x2000+((i<<1)+1)+((i>>4)<<5));  vram_put(metblock[1]);
			vram_adr(0x2000+((i<<1)+32)+((i>>4)<<5)); vram_put(metblock[2]);
			vram_adr(0x2000+((i<<1)+33)+((i>>4)<<5)); vram_put(metblock[3]);
		}
	}
	
	ppu_on_all();//Activamos la visualizacion
}

void visualizar_enemigos(void)//Muestra los enemigos en pantalla
{
	for (i=rango; i<(rango+3); ++i)
	{
		if (enem_x[i]>camara_x && enem_x[i]<camara_x+256 && !enem_desact[i])
		{
			switch (enem_tipo[i])//Mostrar dependiendo cual enemigo sea
			{
				case 1:		//Mostrar en x, y, precargar el sig sprite, sprite correspondiente + animmacion
					spr = oam_meta_spr(enem_x[i]-scr_x,enem_y[i],spr,num_spr_enemigos[(enem_dir[i]<<1)+((enem_anim>>3)&1)]);
					mover_enemigo01();
				break;
				case 2:
					spr = oam_meta_spr(enem_x[i]-scr_x,enem_y[i],spr,num_spr_enemigos[4]);
					mover_enemigo02();
				break;
				case 3:
					spr = oam_meta_spr(enem_x[i]-scr_x,enem_y[i],spr,num_spr_enemigos[5+((enem_anim>>3)&3)]);
					mover_enemigo03();
				break;
			}	
			for (k=0;k<3;++k)
			{	//Colision con los 3 disparos que hagamos
				if (shot_act[k] && shot_x[k]>=enem_x[i]-8 && shot_x[k]<enem_x[i]+16 && shot_y[k]>=enem_y[i]-8 && shot_y[k]<enem_y[i]+16)
				{
					enem_desact[i]=1;
					shot_act[k]=0;
					sfx_play(3,3);
				}
			}
			//Si el personaje le cae por encima
			if (pl_x>=enem_x[i]-16 && pl_x<enem_x[i]+16 && pl_y+16>=enem_y[i] && pl_y+16<enem_y[i]+16)
			{
				pl_vy=-12;//rebotar
				enem_desact[i]=1;//matar al enemigo
				sfx_play(3,3);
			}//Colision personaje para matarlo
			else if (pl_x>=enem_x[i]-16 && pl_x<enem_x[i]+16 && pl_y>=enem_y[i]-16 && pl_y<enem_y[i]+16)
			{
				sfx_play(3,3);//reiniciamos el nivel
				for (k=0;k<16;++k) ppu_wait_nmi();
				//idx=0; En caso de que quieran empezar desde el primer nivel quiten las dos diagonales
				cargar_nivel();
				cargar_enemigos();
				visualizar_el_nivel();
			}
			//si el enemigo se cae al vacio
			if(enem_y[i]>240) enem_desact[i]=1;
			
			en_pantalla[i]=1;//Indicar que esta en pantalla
		}
	}
};

void visualizar_municiones(void)//Disparos que hacemos al pulsar el boton B
{
	for (i=0;i<3;++i)
	{
		if (shot_act[i])
		{
			spr = oam_spr(shot_x[i]-scr_x,shot_y[i],0x40,3,spr);//mostramos el disparo en pantalla
			if (shot_dir[i]) shot_x[i]+=4; else shot_x[i]-=4;//dependiento en la direccion es donde se va a mover
			if (shot_x[i]>camara_x+256 || shot_x[i]<camara_x) shot_act[i]=0;//si se sale de la pantalla que desaparezca
		}
	}
}

void visualizar_datos(void)//Mostrar la cantidad de monedas que hemos coleccionado
{
				// x, y, tile (numeros 0-9), id_color, sig sprite
	spr = oam_spr(32,32,0x10+monedas/10%10,1,spr);//primer digito
	spr = oam_spr(40,32,0x10+monedas%10,1,spr);//segundo digito
}