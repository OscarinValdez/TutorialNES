//tiles que componen cada elemento mencionado
const unsigned char metzero[]=			{ 0x00,0x00,0x00,0x00 };//vacio
const unsigned char metflowers[]=		{ 0x00,0x00,0x79,0x79 };//flores
const unsigned char metcoin[]=  		{ 0x6a,0x6b,0x7a,0x7b };//monedas
const unsigned char metblock[]=			{ 0x88,0x89,0x98,0x99 };//bloques

const unsigned char* const metatile_idx[]=
{//pueden remplazar los primeros 5 metblock por otros metasprites nuevos que hagan para su proyecto
	0,metcoin,metblock,metblock,metblock,metblock,metblock,metblock,
};