extern const unsigned char	chars00a_lzn [];
#define						CHARS00A_LZN_SIZE 0x0036

extern const unsigned char	chars00b_lzn [];
#define						CHARS00B_LZN_SIZE 0x0034

extern const unsigned char	chars01a_lzn [];
#define						CHARS01A_LZN_SIZE 0x003D

extern const unsigned char	chars01b_lzn [];
#define						CHARS01B_LZN_SIZE 0x0033

extern const unsigned char	chars02a_lzn [];
#define						CHARS02A_LZN_SIZE 0x0039

extern const unsigned char	chars02b_lzn [];
#define						CHARS02B_LZN_SIZE 0x0036

extern const unsigned char	chars03a_lzn [];
#define						CHARS03A_LZN_SIZE 0x0036

extern const unsigned char	chars03b_lzn [];
#define						CHARS03B_LZN_SIZE 0x0026

extern const unsigned char	chars04a_lzn [];
#define						CHARS04A_LZN_SIZE 0x0059

extern const unsigned char	chars04b_lzn [];
#define						CHARS04B_LZN_SIZE 0x003B

extern const unsigned char	chars05a_lzn [];
#define						CHARS05A_LZN_SIZE 0x0070

extern const unsigned char	chars05b_lzn [];
#define						CHARS05B_LZN_SIZE 0x003A

extern const unsigned char	chars06a_lzn [];
#define						CHARS06A_LZN_SIZE 0x005D

extern const unsigned char	chars06b_lzn [];
#define						CHARS06B_LZN_SIZE 0x002D

extern const unsigned char	chars07a_lzn [];
#define						CHARS07A_LZN_SIZE 0x0073

extern const unsigned char	chars07b_lzn [];
#define						CHARS07B_LZN_SIZE 0x0047

extern const unsigned char	chars08a_lzn [];
#define						CHARS08A_LZN_SIZE 0x003B

extern const unsigned char	chars08b_lzn [];
#define						CHARS08B_LZN_SIZE 0x0038

extern const unsigned char	chars09a_lzn [];
#define						CHARS09A_LZN_SIZE 0x0045

extern const unsigned char	chars09b_lzn [];
#define						CHARS09B_LZN_SIZE 0x0030

extern const unsigned char	chars10a_lzn [];
#define						CHARS10A_LZN_SIZE 0x003E

extern const unsigned char	chars10b_lzn [];
#define						CHARS10B_LZN_SIZE 0x0014

extern const unsigned char	chars11a_lzn [];
#define						CHARS11A_LZN_SIZE 0x003B

