// Global variables [BSS segment]
static unsigned char update_list[61];//Lista para actualizar ciertas partes del fondo cuando la visualizacion PPU esta activada [3+26+3*7+14+9+11+1];
static unsigned char got[300];//Array para saber cuales objetos (ej. monedas) se han collecionado y cuales aun no (Max 300 objetos coleccionables)

static unsigned int enem_x[30];//Posicion x de los enemigos (Max 30 enemigos)

//Direccion de los enemigos(0=izquierda,1=derecha), Posicion y de los enemigos (Max 30 enemigos), tipo de enmigo(en este caso: 1=rodante, 2=saltarin, o 3=volador),
//Salud de los enemigos (en estecaso siempre 1 pero puede ser editable), desactivar enemigo cuando este muerto, variable que representa la duracion de la animacion de los enemigos
static unsigned char enem_dir[30], enem_y[30], enem_tipo[30], enem_hp[30], enem_desact[30], enem_anim;
static signed char enem_vy[30];//Velicidad vertical para los enmigos saltarines

static unsigned char en_pantalla[30];//Variable para saber si el enemigo esta en pantalla.
static signed char rango;//Variable para controlar cuantos enemigos se visualizaran en pantalla y no se ponga lento el juego (MAX 4).

static unsigned int shot_x[3];//Variables que usaremos para disparar ( x, y, direccion, activo en pantalla, id) MAX 3
static unsigned char shot_y[3], shot_dir[3], shot_act[3], shot_idx;

static unsigned char monedas;//Variable para saber el numero de monedas coleccionadas hasta el momento
