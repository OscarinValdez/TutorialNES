// Global variables [ZP segment]
static unsigned char pad,spr;//variables para controlar y visualizar al personaje

//Ejes del personaje
static unsigned int pl_x; //posicion x (int para numeros mayores a 255 para niveles largos)
static signed int pl_y; //posicion y (signed para numeros negativos ya que si se va arriba de la pantalla, aparece por abajo y cuenta como una muerte)
static unsigned char pl_dir;//Direccion del personaje (0 = izquierda, 1 = derecha)

static signed char pl_vy;//Velocidad vertical para calcular la gravedad (signed para numeros negativos)

//variable para verificar si puede saltar cuando este en tierra y si los botones A o B estan pulsados
static unsigned char puede_saltar, a_pulsado, b_pulsado;

static unsigned char idx, sprite_idx;//variables para usarse como id para indicar ya sea el nivel o el sprite correspondientes
static unsigned char fotograma;//para indicar la duracion de la animacion de los sprites del personaje entre fotogramas

static unsigned int ii,jj,kk;//variables de numeros largos para usarse para calcular posiciones fijas en el mapa de cuadricula de 16x15
static unsigned int i16, k32, old_camara_x, camara_x, cix, scr_x, show_x;//variables para calcular otras posiciones fijas y la camara y controlar la posicion x del personaje en pantalla

static unsigned int quitar;//con esto borramos una parte del fondo en cuadricula (ej: al coleccionar monedas)

static unsigned char j16, i, j, k, tira;//variables cortas para usarse en ciclos for
