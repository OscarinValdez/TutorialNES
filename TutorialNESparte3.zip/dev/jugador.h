void coll_moneda(void)//Coleccionammos la moneda correspondiente
{		// En que nametable estamos ubicados y en que parte del fondo tanto X como Y
	quitar=(0x2000+(0x400*((pl_x>>8)&1)))+((i16&15)<<1)+(j16<<6);
	// Borramos la moneda correspondiente
	update_list[50]= MSB(quitar)|NT_UPD_HORZ;//Borramos dos tiles en horizontal
	update_list[51]= LSB(quitar);
	update_list[52]= 2;

	update_list[53]= 0;
	update_list[54]= 0;
	quitar+=32;
	
	update_list[55]= MSB(quitar)|NT_UPD_HORZ;//Otros dos tiles abajo
	update_list[56]= LSB(quitar);
	update_list[57]= 2;

	update_list[58]= 0;
	update_list[59]= 0;
	
	sfx_play(1,1);//reproduce el sonido correspondiente
	++monedas;//Le indicamos que tenemos una moneda
}

void mover_jugador(void)//Hacia donde se va a mover (izquierda derecha)
{
	pad=pad_poll(0);

	if(pad&PAD_LEFT &&pl_x>  0//(cada cuadricula mide 16x16 pixeles)
	   && nivel_cuadricula[(((pl_x-1)>>4)&15)+((pl_y>>4)<<4)]!=6 )
	{	
		pl_x-=2;//nos movemos dos pixeles hacia la izquierda
		pl_dir=0;// direccion (0= izquierda, 1= derecha)
		sprite_idx=0;// sprite correspondiente
		fotograma++;// iniciar duracion de la animacion
	}
	else
	if(pad&PAD_RIGHT
	&& nivel_cuadricula[(((pl_x+16)>>4)&15)+((pl_y>>4)<<4)]!=6 ) 	
	{
		pl_x+=2;//nos movemos dos pixeles hacia la derecha
		pl_dir=1;// direccion (0= izquierda, 1= derecha)
		sprite_idx=2;// sprite correspondiente
		fotograma++;// iniciar duracion de la animacion
	}
	else fotograma=0;//si no se mueve entonces que se detenga la duracion

	//SALTAR
	if(pad&PAD_A)
	{	//Si esta pisando suelo o bloques flotando y pulsa el boton A
		if (puede_saltar==1 && a_pulsado==0)
		{
			pl_vy=-12;
			sfx_play(0,0);
		}
		a_pulsado=1; 
	}
	else a_pulsado=0;
	
	//controlar la gravedad para que no caiga muy rapido
	if (pl_vy>4) pl_vy=4; else ++pl_vy;
	
	pl_y+=pl_vy;//controlamos la friccion cuando ya no este en tierra
	
	//PISAR SUELO
	//(cada cuadricula mide 16x16 pixeles)
	if (nivel_cuadricula[((pl_x>>4)&15)+(((pl_y>>4)+1)<<4)]==6
	|| nivel_cuadricula[(((pl_x+15)>>4)&15)+(((pl_y>>4)+1)<<4)]==6)
	{ pl_vy=0; pl_y=(pl_y>>4)<<4; puede_saltar=1; }
	else puede_saltar=0;//<-- para que no pueda saltar en el aire
	
	//CHECAR COLISION ARRIBA DEL PERSONAJE
	if (nivel_cuadricula[((pl_x>>4)&15)+((((pl_y-1)>>4))<<4)]==6
	|| nivel_cuadricula[(((pl_x+15)>>4)&15)+((((pl_y-1)>>4))<<4)]==6)
		pl_vy=0;
	
	//COLECIONANDO MONEDAS
	i16= (pl_x+8) >> 4;//con estas variables calculamos las pocisiones x,y del personaje en la cuadricula
	j16= pl_y >> 4;//(cada cuadricula mide 16x16 pixeles)
	cix= (pl_x+16) >> 4;
	
	if (nivel_cuadricula[(j16<<4)+(i16&15)]>=11&&nivel_cuadricula[(j16<<4)+(i16&15)]<100)
	{
		coll_moneda();
		got[nivel_cuadricula[(j16<<4)+(i16&15)]]=1;
		nivel_cuadricula[(j16<<4)+(i16&15)]=0;
	}
	/*
	if (nivel_cuadricula[(j16<<4)+(cix&15)]>=11&&nivel_cuadricula[(j16<<4)+(cix&15)]<100)
	{
		quitar=(0x2000+(0x400*((pl_x>>8)&1)))+((cix&15)<<1)+(j16<<6);
		coll_moneda();
		got[nivel_cuadricula[(j16<<4)+(cix&15)]]=1;
		nivel_cuadricula[(j16<<4)+(cix&15)]=0;
	}
	*/
	if (nivel_cuadricula[(j16<<4)+(i16&15)]==2//Si entramos a la puerta o nos caemos al vacio
	|| pl_y>240)
	{
		if (nivel_cuadricula[(j16<<4)+(i16&15)]==2) ++idx;
		sfx_play(2,3);
		for (i=0;i<16;++i) ppu_wait_nmi();
		cargar_nivel();
		cargar_enemigos();
		visualizar_el_nivel();
	}
	
	//DISPARAR
	if(pad&PAD_B && !b_pulsado)
	{
		shot_act[shot_idx&2]=1;
		shot_dir[shot_idx&2]=pl_dir;
		shot_x[shot_idx&2]=pl_dir?pl_x+16:pl_x-9;
		shot_y[shot_idx&2]=pl_y+4;
		++shot_idx;
		sfx_play(4,2);
		b_pulsado=1;
	}
	else if(!(pad&PAD_B))
	{
		b_pulsado=0;
	}
	
	if (pad & PAD_START)//PAUSA
	{
		while (pad_poll (0) & PAD_START);
		music_pause (1);
		sfx_play (5, 3);		
		pal_bright (0);
		//ppu_wait_nmi ();
		while (!(pad_poll (0) & PAD_START));
		pal_bright (4);
		music_pause (0);
		while (pad_poll (0) & PAD_START);
	}
};