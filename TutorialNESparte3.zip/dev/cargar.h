void cargar_lista(void)//Preparamos la lista para poder actualizar los tiles que se guardaran durante el desplazamiento de la pantalla
{
	update_list[0]=0x20|NT_UPD_VERT;//para los tiles (en columna vertical)
	update_list[1]=0x00;
	update_list[2]=26;
	
	for (i=3;i<29;++i) update_list[i]=0;
	
	update_list[29]=0x20|NT_UPD_VERT;//para los atributos (colores)
	update_list[30]=0x00;
	update_list[31]=17;
	
	for (i=32;i<50;++i) update_list[i]=0;//para las monedas coleccionadas
	
	update_list[50]= 0x20|NT_UPD_HORZ;//en hileras de 2 en 2
	update_list[51]= 0x00;
	update_list[52]= 2;

	update_list[53]= 0;
	update_list[54]= 0;
	
	update_list[55]= 0x20|NT_UPD_HORZ;;
	update_list[56]= 0x00;
	update_list[57]= 2;
	
	update_list[58]= 0;
	update_list[59]= 0;
}

void cargar_cuadricula(void)
{
	for (i=0;i<208;++i) nivel_cuadricula[i]=0;//Definir el fondo del cielo
	for (i=208;i<240;++i) nivel_cuadricula[i]=6; //Definir el suelo
}

void cargar_nivel(void)//cargamos los primeros datos mencionados
{
	ppu_off();
	oam_clear();
	
	scr_x=0;
	rango=0;
	
	show_x= pl_x-8;
	jj=0;
	kk=0;
	i16=1;
	
	pl_x=52;//inicio del eje x del personaje en pixeles
	pl_y=100;//inicio del eje y del personaje en pixeles
	sprite_idx=2;
	pl_dir=1;
	
	for (ii=0;ii<300;++ii) got[ii]=0;//precargamos los objetos coleccionables (en este caso monedas)
	
	vram_adr(0x2000);//vaciamos el fondo
	vram_fill(0,960);
	
	cargar_lista();
	cargar_cuadricula();
	
	music_play(0);//volvemos a reproducir la musica en caso de que perdamos
}