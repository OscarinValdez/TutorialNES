This little project template contains work from several people:

- Shiru - Neslib and original crt0.s file.
- Tokumaru - lzss decompressor.
- na_th_an - project template, neslib and crt0 modifications, cfg file, lzss compresor port to freebasic

You can find tokumaru's original package here: http://membler-industries.com/tokumaru/tokumaru_lzss.zip
If you need help (there's no documentation) just reach me at nesdev.com

Happy coding! - na_th_an


Short documentation
===================

Read more on UxROM mappers at nesdev: 

This package is a simple framework using cc65 and Shiru's neslib aimed to create games using the UNROM mapper configured for 64K of PRG-ROM and 8K of CHR-RAM. ROM is divided in 4 pages of 16K, ROM0 to ROM3. ROM3 is fixed at position $C000 in the memory map, and contains crt0 code, neslib, famitone2, your main code, and the jump vectors. ROM0 to ROM2 can be allocated one at a time at position $8000, just below ROM3.

Included is a nes-unrom.cfg file which contains the memory map setup for the linker. crt0-unrom.s contains startup code and the iNES header definition, and includes neslib-unrom.s and famitone2.s.

neslib-unrom.s (and header file neslib-unrom.h) is a modified version of Shiru's neslib with two new functions:

void __fastcall__ tokumaru_lzss (void *input_data, int output_address);

Will uncompress a lzss compressed binary allocated anywhere in the mapped ROM space to any address in the PPU address space. Use this as a means of copying pattern data and nametable data to the VRAM.

void __fastcall__ bankswitch (unsigned char bank);

Will map ROM "bank" (ranging from 0 to 2) at position $8000 in the address space. Once a ROM bank is paged in, you can read data from it or execute functions placed in such bank. 

For your convenience, I've included a main skeleton c file with every sensible section in the memory map referenced. The file game.c includes several other files and instructs the linker to place them in the proper places in the memory map. Adding your code to such files will guarantee everything is in place. Those are the files:

ram/zp.h

Add your global variable definitions for the Zero page here.

ram/bss.h

Add the rest of your global variable definitions here.

rom/rom0.h
rom/rom1.h
rom/rom2.h

You can add code and data here and it will be placed in the correct ROM bank.

Everything else you place or include in main.c after this block:

#pragma rodata-name	("CODE")
#pragma code-name	("CODE")

will be in the fixed ROM3 bank.

Whenever you need to use an asset or call a function located in one of the switchable banks, call "bankswitch" before doing so, then do it normally. Of course, if you are getting track of which ROM is paged in and the correct one is already in place, you don't need to call "bankswitch" every time.

There's no memory manager, so you can't really call a function located in a switchable bank from another switchable bank. It has to be done from the main bank (see "TODO").

About lzss compressed binaries
==============================

I've ported Tokumaru's original compression script to freeBASIC and produced a compiled version which is a tad faster - and which is portable, as well (freeBASIC is available for several platforms including Linux). The original compression script is still included.

To call the compressor (can be added to your toolchain):

$ lzsscomp.exe input.bin output.bin|output.h

The output format is based on file extension. If the output filename has a .bin extension, a binary file will be produced. If the output filename has a .h extension, a C source array will be produced.

This will create the compressed file in the same folder as the original binary file.

I've included a collection of the utilities I usually use and which I wrote myself, feel free to explore - all of them are command line tools. There's a simple folder2c implementation which may come in handy to get binary files into .c code arrays. Feel free to ask.

About music and sound effects (famitone2)
=========================================

There's an extra layer of complexity to make music work (not sound effects, those are handled as always as I've found fit that they reside in the fixed bank).

You can now have several sets of songs, and place them accross switchable banks as you see fit (even in the fixed bank). The first thing you must do is find a way to make the song data to be added in the correct bank, then export a symbol you can use from your C code. The easiest way I've come up with to make this is as follows:

1.- Create your song collection in famitracker, as always.
2.- Export in txt, and use text2data.exe to generate music.s. Rename music.s to music_ROMx.s, with "x" the number of your ROM bank
3.- Edit music_ROM0.s, and add this at the beginning:

	.segment "ROMx"
	.export _music_ROMx

	_music_ROMx:

	Replace "x" in every line with the number of your ROM bank. You can do this for each bank if you need.

4.- You have to compile your music_ROMx.s files separately. Add this to your makefile/batch file for each music file:

	ca65 music_ROMx.s

5.- When linking your game, just add the new .o files to the list, for example:

	ld65 -C nes-unrom.cfg -o mygame.nes crt0-unrom.o mygame.o music_ROM0.o runtime.lib  -Ln labels-%1.txt

6.- In your main code, import the extern symbols (in the "CODE" section):

	// Music pointer(s)
	extern const unsigned char music_ROMx [];

	Again, do it for every ROM binary, replacing "x" with the bank number.

7.- whenever you need to initialize a new song collection, use the function famitone_init:

	void __fastcall__ famitone_init (unsigned char bank, const unsigned char *song_data);

	Use the correct bank and the "music_ROMx" array as the pointer to song data.

If you find this confusing, just look at the examples or reach me in the forums.

Examples
========

In the example folders there's a very simple example called 03_dummy.c (in fact, this is what I used to make sure everything was working properly). The example just unpacks 8 compressed patterns twice to CHR-RAM, then prints them on screen. Compressed pattern data and the function which prints them are in different ROM pages.

Another example, 04_famitone.c, shows how to use music loaded in a different bank (ROM2, in this case).

TODO
====

- I have in mind to implement a simple way to call functions located in the switchable banks. Such function would take two parameters: a bank number and a function name, and would automaticly page in the required bank then call the function. A flag could be used to tell the function to restore the bank which was paged in after calling the function, which may come up handy.

NOTE: The music.s/sounds.s files are just empty placeholders.
